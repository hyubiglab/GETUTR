import sys, os
from subprocess import Popen, PIPE, STDOUT

import utility as util

#inputFile = sys.argv[1]

def readbam(inputFile, library):
	print "samtools..."
	print inputFile
	maxLen = 0; bed = dict()
	commandBase = 'samtools view ' + inputFile
	output = ''
	if True:
		p=Popen(commandBase, shell=True, stdout=PIPE, stdin=PIPE, stderr=PIPE)
		output=p.stdout.readlines()
		for line in output:
			line = line.strip('\n').split('\t')
			chr = line[2]
			flag = line[1]
			sense = util.getStrand(flag, library)
			start = int(line[3])
			cigar = line[5]
			seqLen = len(line[9])
			end = util.getPos(start, cigar, seqLen)
			tag = line[0]
			qual = line[4]
			key = int(start/10000)
			if not bed.has_key(chr): bed[chr] = dict()
			if not bed[chr].has_key(key): bed[chr][key] = []
			bed[chr][key].append([start, end, sense, qual, tag])
			
			if maxLen < end-start: maxLen = end-start

	print 'done'
	return bed, maxLen

def readbed(inputFile):
	print "reading bed file..."
	maxLen = 0; bed = dict()
	fin = open(inputFile, "r")
	for line in fin:
		line = line.split('\t')
		chr = line[0]
		sense = line[5].rstrip()
		start = int(line[1])+1
		end = int(line[2])+1
		tag = line[3]
		qual = int(line[4])
		key = int(start/10000)
		if not bed.has_key(chr): bed[chr] = dict()
		if not bed[chr].has_key(key): bed[chr][key] = []
		bed[chr][key].append([start, end, sense, qual, tag])

		if maxLen < end-start: maxLen = end-start

	print 'done'
	return bed, maxLen

def gtftogenepred(loc):
	refOut = loc[:-3] + 'genePred'
	commandBase = 'gtfToGenePred ' + loc + ' ' + refOut
	output = ''
	if True:
		p=Popen(commandBase, shell=True, stdout=PIPE, stdin=PIPE, stderr=PIPE)
		output=p.stdout.readlines()
	return refOut

def removegenepred(loc):
	commandBase = 'rm -f ' + loc
	output = ''
	if True:
		p=Popen(commandBase, shell=True, stdout=PIPE, stdin=PIPE, stderr=PIPE)
		output=p.stdout.readlines()
