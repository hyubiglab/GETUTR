import sys, os

def getStrand(flag, library):
	if library=='fr-unstranded':
		sense_flag = [0]
		antitsense_flag = [16]
	elif library=='fr-firststrand':
		sense_flag = [16, 83, 163, 67, 131, 81, 161, 65, 129, 89, 137]
		antisense_flag = [0, 73, 99, 147, 115, 179, 97, 145, 113, 177, 121, 185, 153]
	elif library=='fr-secondstrand':
		sense_flag = [0, 73, 99, 147, 67, 131, 97, 145, 65, 129, 137, 153]
		antisense_flag = [16, 89, 121, 83, 163, 115, 179, 81, 161, 113, 177, 185]
	
	if flag >= 265: flag = flag-256

	if flag in sense_flag: strand = '+'
	elif flag in antisense_flag: strand = '-'
	else: strand = '.'

	return strand

def getPos(pos, cigar, length):
	last = 0
	N = [0,0]; I = [0,0]; D = [0,0]
	tags = ['N', 'I', 'D', 'M']
	for j in range(len(cigar)):
		if cigar[j]=='N':
			n = int(cigar[last+1:j])
			N.append(n)
		elif cigar[j]=='D':
			d = int(cigar[last+1:j])
			D.append(d)
		elif cigar[j]=='I':
			i = int(cigar[last+1:j])
			I.append(i)
		else: pass

	pos = pos + length - 1 + sum(N) + sum(D) - sum(I)
	return pos
