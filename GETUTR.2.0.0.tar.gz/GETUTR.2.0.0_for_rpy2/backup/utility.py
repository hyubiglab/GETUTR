import sys, os

class Locus:
    # this may save some space by reducing the number of chromosome strings
    # that are associated with Locus instances (see __init__).
    __chrDict = dict()
    __senseDict = {'+':'+', '-':'-', '.':'.'}
    # chr = chromosome name (string)
    # sense = '+' or '-' (or '.' for an ambidexterous locus)
    # start,end = ints of the start and end coords of the locus;
    #       end coord is the coord of the last nucleotide.
    def __init__(self,chr,start,end,sense):
        coords = [start,end]
        coords.sort()
        # this method for assigning chromosome should help avoid storage of
        # redundant strings.
        if not(self.__chrDict.has_key(chr)): self.__chrDict[chr] = chr
        self._chr = self.__chrDict[chr]
        self._sense = self.__senseDict[sense]
        self._start = min(map(int, coords))
        self._end = max(map(int, coords))
    def chr(self): return self._chr
    def start(self): return self._start  ## returns the smallest coordinate
    def end(self): return self._end   ## returns the biggest coordinate
    def len(self): return self._end - self._start + 1
    def getAntisenseLocus(self):
        if self._sense=='.': return self
        else:
            switch = {'+':'-', '-':'+'}
            return Locus(self._chr,self._start,self._end,switch[self._sense])
    def coords(self): return [self._start,self._end]  ## returns a sorted list of the coordinates
    def sense(self): return self._sense
    # returns boolean; True if two loci share any coordinates in common
    def overlaps(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif not(self._sense=='.' or \
                 otherLocus.sense()=='.' or \
                 self.sense()==otherLocus.sense()): return False
        elif self.start() > otherLocus.end() or otherLocus.start() > self.end(): return False
        else: return True

    def overlaps_bothDir(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif self.start() > otherLocus.end() or otherLocus.start() > self.end(): return False
        else: return True
    def exactMatch(self, otherLocus):
	if self.chr()!=otherLocus.chr(): return False
	elif not(self._sense=='.' or otherLocus.sense()=='.' or self.sense()==otherLocus.sense()): return False
	elif self.start() != otherLocus.start(): return False
	else: return True
    # returns boolean; True if all the nucleotides of the given locus overlap
    #      with the self locus
    def contains(self,otherLocus):
        if self.chr()!=otherLocus.chr(): return False
        elif not(self._sense=='.' or \
                 otherLocus.sense()=='.' or \
                 self.sense()==otherLocus.sense()): return False
        elif self.start() > otherLocus.start() or otherLocus.end() > self.end(): return False
        else: return True
        
    # same as overlaps, but considers the opposite strand
    def overlapsAntisense(self,otherLocus):
        return self.getAntisenseLocus().overlaps(otherLocus)
    # same as contains, but considers the opposite strand
    def containsAntisense(self,otherLocus):
        return self.getAntisenseLocus().contains(otherLocus)
    def __hash__(self): return self._start + self._end
    def __eq__(self,other):
#        if self.__class__ != other.__class__: return False
        if self.chr()!=other.chr(): return False
        if self.start()!=other.start(): return False
        if self.end()!=other.end(): return False
        if self.sense()!=other.sense(): return False
        return True
    def __ne__(self,other): return not(self.__eq__(other))
    def coord(self): return self.chr()+':'+'-'.join(map(str,self.coords()))
    def __str__(self): return self.chr()+'('+self.sense()+'):'+'-'.join(map(str,self.coords()))
    def checkRep(self):

class Gene:
    # name = name of the gene (string)
    # txCoords = list of coords defining the boundaries of the transcipt
    # cdCoords = list of coords defining the beginning and end of the coding region
    # exStarts = list of coords marking the beginning of each exon
    # exEnds = list of coords marking the end of each exon
    # IF THIS IS A NON-CODING GENE, cdCoords => [0,0]
    def __init__(self,name,id,chr,sense,txCoords,cdCoords,exStarts,exEnds):
         self._name = name
         self._geneID = id
         self._txLocus = Locus(chr,min(txCoords),max(txCoords),sense)
         if cdCoords == None:
             self._cdLocus = None
         else:
             self._cdLocus = Locus(chr,min(cdCoords),max(cdCoords),sense)

         exStarts = map(lambda i: i, exStarts)
         exEnds = map(lambda i: i, exEnds)
         exStarts.sort()
         exEnds.sort()
         if len(exStarts)!=len(exEnds):
             raise ValueError('the number of exon starts ('+str(len(exStarts))+\
                              ') and exon ends ('+str(len(exEnds))+') doesn\'t match.')

         self._txExons = []
         self._cdExons = []
         self._introns = []

         cd_exon_count = 0

         for n in range(len(exStarts)):
             first_locus = Locus(chr,exStarts[n],exStarts[n],sense)
             second_locus = Locus(chr,exEnds[n],exEnds[n],sense)

             # Add the transcription unit exon
             tx_exon = Locus(chr,exStarts[n],exEnds[n],sense)

             self._txExons.append(tx_exon)
             # Add Coding Exons
             # Need to make sure that the current exon is actually in the coding region of the gene first
             if self.isCoding() and tx_exon.overlaps(self._cdLocus):
                 if not first_locus.overlaps(self._cdLocus):
                     first_coord = min(cdCoords)
                 else:
                     first_coord = exStarts[n]

                 if not second_locus.overlaps(self._cdLocus):
                     second_coord = max(cdCoords)
                 else:
                     second_coord = exEnds[n]
		 if len(self._cdExons)==0:
                 	new_cd_exon = Locus(chr,first_coord+1,second_coord,sense)
                 	self._cdExons.append(new_cd_exon)
		 else:
                 	new_cd_exon = Locus(chr,first_coord,second_coord,sense)
                 	self._cdExons.append(new_cd_exon)
		
             # Add Introns
             if n < len(exStarts)-1:
                 self._introns.append(Locus(chr,exEnds[n]+1,exStarts[n +1]-1,sense))
         if self.isCoding():
             if sense=='+':
                 self._fpUTR = Locus(chr,min(txCoords),min(cdCoords)-1,sense)
                 self._tpUTR = Locus(chr,max(cdCoords)+1,max(txCoords),sense)
             elif sense=='-':
                 self._fpUTR = Locus(chr,max(cdCoords)+1,max(txCoords),sense)
                 self._tpUTR = Locus(chr,min(txCoords),min(cdCoords)-1,sense)
         else:
             self._fpUTR = None
             self._tpUTR = None

	 self._fpExons=[];self._tpExons=[]
	 for n in range(len(self._txExons)):
	     txExon = self._txExons[n]
	     if txExon.end()<min(cdCoords): self._fpExons.append(txExon)
	     if txExon.end()>=min(cdCoords) and txExon.start()<min(cdCoords): 
		 new_txExon = Locus(txExon.chr(),txExon.start(),min(cdCoords)-1,sense) 
		 self._fpExons.append(new_txExon)
	     if txExon.end()>max(cdCoords) and txExon.start() < max(cdCoords):
		 new_txExon = Locus(txExon.chr(),max(cdCoords) + 1,txExon.end(),sense)
		 self._tpExons.append(new_txExon)
	     if txExon.start() > max(cdCoords): self._tpExons.append(txExon)
         
    def name(self): return self._name
    def geneID(self): return self._geneID
    def chr(self): return self._txLocus.chr()
    def sense(self): return self._txLocus.sense()
    def txLocus(self): return self._txLocus   ## locus of full transcript
    def cdLocus(self): return self._cdLocus   ## locus from start codon to end codon
    def txExons(self): return map(lambda i: i, self._txExons)  ## list of loci
    def cdExons(self): return map(lambda i: i, self._cdExons)  ## list of loci
    def introns(self): return map(lambda i: i, self._introns)  ## list of loci
    def fpExons(self,sense): 
	 if sense=='+':return map(lambda i: i, self._fpExons)
	 else:return map(lambda i: i, self._tpExons)  ## list of loci
    def tpExons(self,sense): 
	 if sense=='+':return map(lambda i: i, self._tpExons)
	 else:return map(lambda i: i, self._fpExons)  ## list of loci
    def fpUtr(self): return self._fpUTR  ## locus
    def tpUtr(self): return self._tpUTR  ## locus
    def isCoding(self): return not(self._cdLocus.start()==0 and self._cdLocus.end()==0)  # boolean; is this gene protein-coding?
    def __hash__(self): return self._txLocus.__hash__()

# the test lambda takes one Gene instance as an argument
def getRefFlatUniq(genomeName, location='', test = lambda g: True):
    genomeToFile = dict()
    geneAnnobyChrom = getRefFlatbyChrom(genomeName, location)

    geneAnno = dict()
    chromosomes = geneAnnobyChrom.keys()
    if genomeName=='hg19': 
    		chromosomes = []
		for i in range(1,23)+['M', 'X', 'Y']: chromosomes.append('chr' + str(i))
    if genomeName=='danRer7':
    		chromosomes = []
		for i in range(1,26)+['M']: chromosomes.append('chr' + str(i))
    if genomeName=='mm9':
    		chromosomes = []
		for i in range(1,20)+['M', 'X', 'Y']: chromosomes.append('chr' + str(i))
    for chrom in chromosomes:
        genes = geneAnnobyChrom.get(chrom,[])
        for gene in genes: geneAnno[gene[2].name()] = gene[2]

    geneAnno2 = dict()
    for genename in geneAnno.keys():
	geneAnno2[geneAnno[genename].geneID()] = geneAnno[genename]
    return geneAnno2

def getRefFlatbyChrom(genomeName, location='', test = lambda g: True):
    genomeToFile = dict()
    genomeToFile['custom'] = location

    filename = genomeToFile[genomeName]
    geneList = dict()
    f = open(filename)
    lines = f.readlines()
    for line in lines:
        raw_line = line.split('\t')
	#if len(raw_line)==10: raw_line.insert(1, raw_line[0])
        if raw_line[2]=='+' or raw_line[2]=='-': raw_line.insert(1, raw_line[0])
        name = raw_line[0]
        geneID = raw_line[1]
        chr = raw_line[2]
        sense = raw_line[3]
        txCoords = map(int,raw_line[4:6])
        cdCoords = map(int,raw_line[6:8])
        exStarts = map(int,raw_line[9].split(',')[:-1])
        exEnds = map(int,raw_line[10].split(',')[:-1])
        # fix the edges to work with the Gene specs
        #exEnds = map(lambda n: n-1, exEnds)
	exStarts = map(lambda n: n+1, exStarts)
	#exStarts[0]+=1

        txCoords = [txCoords[0], txCoords[1] ]
        cdCoords = [cdCoords[0], max([cdCoords[1], 0])]
        if cdCoords[0]!=0 or cdCoords[1]!=0:
            newGene = Gene(name,geneID,chr,sense,txCoords,cdCoords,exStarts,exEnds)
            if not(geneList.has_key(chr)): geneList[chr] = []
            geneList[chr].append([txCoords[0],txCoords[1],newGene])
    f.close()
    return geneList
