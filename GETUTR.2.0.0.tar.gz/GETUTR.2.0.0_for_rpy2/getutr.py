#!/share/apps/python/bin/python

import sys, random
from rpy2 import *
from types import *
#import numpy

import filemanager as fm
import smoothing as smooth
import cleavage as cleav 

outputSmoothed = 1
outputCleavage = 1

## Input Arguments and Preprocessing ##
method = 10
fileOut = 'default'
inputBED = 'default.bed'
ref = 'hg19'
refloc = ''

ptr = 1
if len(sys.argv) < 3:
	print 'GETUTR.2.0.0: Global Estimation of the 3\' Untranslated Region Landscape using RNA-Seq'
	print ' usage: python getutr.py [OPTION] [PARAMETER]...'
	print ' ex) python getutr.py -i input.BED -o output\n'
	print 'options:'
	print '%-24s %-50s'%(' -i <inputfile name>','input BAM/BED file')
	print '%-24s %-50s'%(' -o <outputfile name>','name for outputs')
	print '%-24s %-50s'%(' ','default: <inputfile name>')
	print '%-24s %-50s'%(' -m <index of method>','index for smoothing method')
	print '%-24s %-50s'%(' ','default: 10 (PAVA)')
	print '%-24s %-50s'%(' -r <reference file>','reference file for gene annotation')
	print '%-24s %-50s'%(' ','default: hg19')
	print '%-24s %-50s'%(' -h, --help','show this screen\n')
	print 'index of method:'
	print '%3s\t%-10s'%('0','Max.fit')
	print '%3s\t%-10s'%('1','Min.fit')
	print '%3s\t%-10s'%('10','PAVA')
	sys.exit(0)

while ptr < len(sys.argv) and len(sys.argv) > 2:
	if sys.argv[ptr]=='-i':
		ptr += 1
		inputFile = sys.argv[ptr]
	elif sys.argv[ptr]=='-o':
		ptr += 1
		fileOut = sys.argv[ptr]
	elif sys.argv[ptr]=='-m':
		ptr += 1
		method = int(sys.argv[ptr])
	elif sys.argv[ptr]=='-r':
		ptr += 1
		ref = 'custom'
		refloc = sys.argv[ptr]
	elif sys.argv[ptr]=='-h' or sys.argv[ptr]=='--help':
		print 'GETUTR: Global Estimation of the 3\' Untranslated Region Landscape using RNA-Seq'
		print ' usage: python getutr.py [OPTION] [PARAMETER]...'
		print ' ex) python getutr.py -i input.BED -o output\n'
		print 'options:'
		print '%-24s %-50s'%(' -i <inputfile name>','input BAM/BED file')
		print '%-24s %-50s'%(' -o <outputfile name>','name for outputs')
		print '%-24s %-50s'%(' ','default: <inputfile name>')
		print '%-24s %-50s'%(' -m <index of method>','index for smoothing method')
		print '%-24s %-50s'%(' ','default: 10 (PAVA)')
		print '%-24s %-50s'%(' -r <reference file>','reference file for gene annotation')
		print '%-24s %-50s'%(' ','default: hg19')
		print '%-24s %-50s'%(' -h, --help','show this screen\n')
		print 'index of method:'
		print '%3s\t%-10s'%('0','Max.fit')
		print '%3s\t%-10s'%('1','Min.fit')
		print '%3s\t%-10s'%('10','PAVA')
		sys.exit(0)	
	else:
		ptr += 1
	ptr += 1

if method==10: methods = "PAVA"
elif method==0: methods = "Max.fit"
elif method==1: methods = "Min.fit"
else: methods = "PAVA"

print "GETUTR.2.0.0 start..."

if inputFile[-3:]=='bam' or inputFile[-3:]=='BAM':
	if fileOut=='default': fileOut = inputFile[:-4]
#	inputBED, maxLen = fm.readbam(inputFile, library="fr-unstranded")
	inputBED, maxLen = fm.readbam(inputFile, library="fr-firststrand")
elif inputFile[-3:]=='bed' or inputFile[-3:]=='BED':
	if fileOut=='default': fileOut = inputFile[:-4]
	inputBED, maxLen = fm.readbed(inputFile)
else:
	if fileOut=='default': fileOut = inputFile
	inputBED, maxLen = fm.readbed(inputFile)
#sys.exit(0)

if ref=='custom':
	if refloc[-3:]=='gtf' or refloc[-3:]=='GTF':
		refloc = fm.gtftogenepred(refloc)

estimatedUTR = smooth.smoothing(inputBED, maxLen, methods, ref, refloc)
if ref=='custom':
	if refloc[-8:]=='genePred': fm.removegenepred(refloc)

if outputSmoothed == 1:
	fout = open(fileOut + "." + methods + ".smoothed.2.0.0.bed", "w")
	for geneid in estimatedUTR.keys():
		usages = estimatedUTR[geneid]
		if len(usages) > 0:
			fout.write('track name=\"GETUTR_bed\" description=\"3\' UTR of ' + geneid + ' by GETUTR\" colorByStrand=\"213,62,79 50,136,189\"\n')
			for usage in usages:
				maxv = str(max(usage[1:3]))
				minv = str(min(usage[1:3]))
				chr = usage[0]
				value = str(usage[3])
				strand = usage[4]
				fout.write(chr + "\t" + minv + "\t" + maxv + "\t" + geneid + "\t" + value + "\t" + strand + "\n")
fout.close()

cps = cleav.cpsDetect(estimatedUTR)
estimatedCPS, cps = cleav.makeSeq(estimatedUTR, cps)

if outputCleavage == 1:
	fout_cps = open(fileOut + "." + methods + ".cps.2.0.0.bed", "w")
	for geneid in cps.keys():
		if len(cps[geneid]) > 0:
			for item in cps[geneid]:
				item = map(str,item)
				fout_cps.write(str(item[0]) + "\t" + str(item[2]) + "\t" + str(int(item[2])+1) + "\t" + geneid + "\t" + str(item[3]) + "\t" + str(item[1]) + "\n") ##for bedfile format
fout_cps.close()
